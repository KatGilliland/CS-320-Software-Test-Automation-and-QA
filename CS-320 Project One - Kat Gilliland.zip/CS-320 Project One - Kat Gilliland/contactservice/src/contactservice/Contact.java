package contactservice;

// Creating variables for Contact class KG
public class Contact {

private String contactID;
private String firstName;
private String lastName;
private String phoneNumber;
private String address;

// Creating parameterized constructor KG
public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {

	if (contactID == null || contactID.length()>10){// Contact ID cannot be null OR over 10 characters KG
        throw new IllegalArgumentException("Invalid contact ID"); // Throwing exception if ID does not match expected parameters KG
    }
    if (firstName == null || firstName.length()>10){ // First name cannot be null OR over 10 characters KG 
        throw new IllegalArgumentException("Invalid first name"); // Throwing exception if ID does not match expected parameters KG
    }
    if (lastName == null || lastName.length()>10){ // Last name cannot be null OR over 10 characters KG 
        throw new IllegalArgumentException("Invalid last name"); // Throwing exception if ID does not match expected parameters KG
    }
    if (phoneNumber == null || phoneNumber.length()!=10){ // Phone number cannot be null OR greater or less than 10 (must be exactly 10) KG
        throw new IllegalArgumentException("Invalid phone number"); // Throwing exception if phone number does not match expected parameters KG
    }
    if (address == null || address.length()>30){ // Address cannot be null OR over 30 characters KG
        throw new IllegalArgumentException("Invalid address"); // Throwing exception if address does not match expected parameters KG
    }
    
    // If conditions pass, the information below is set KG
    this.contactID = contactID;
    this.firstName = firstName;
    this.lastName = lastName;
    this.phoneNumber = phoneNumber;
    this.address = address;
}
// Getting contact KG
public String getContact() {
return contactID;
}

// Setting contact KG
public void setContact(String contactID) {
this.contactID = contactID;
}

// Getting first name KG
public String getFirstName() {
return firstName;
}

// Setting first name KG
public void setFirstName(String firstName) {
this.firstName = firstName;
}

// Getting last name KG
public String getLastName() {
return lastName;
}

// Setting last name KG
public void setLastName(String lastName) {
this.lastName = lastName;
}

// Getting phone number KG
public String getPhoneNumber() {
return phoneNumber;
}

// Setting phone number KG
public void setPhoneNumber(String phoneNumber) {
this.phoneNumber = phoneNumber;
}

// Getting address KG
public String getAddress() {
return address;
}

// Setting address KG
public void setAddress(String address) {
this.address = address;
}
}