package contactservice;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test // Testing adding contact KG
    public void testAddContact() {
        Contact contact = new Contact("01", "Ray", "Vans", "1112223333", "53 Cool St");
        ContactService contactService = new ContactService();
        assertTrue(contactService.addContact(contact)); // Adding contact first time, should return true KG
        assertFalse(contactService.addContact(contact)); // Adding the same contact again, should return false KG
    }

    @Test // Testing deleting contact KG
    public void testDeleteContact() {
    	Contact contact = new Contact("01", "Ray", "Vans", "1112223333", "53 Cool St");
        ContactService contactService = new ContactService();
        assertTrue(contactService.addContact(contact));
        assertFalse(contactService.deleteContact("1")); // Cannot delete a contact that does not exist, return false KG
        assertTrue(contactService.deleteContact("01")); // If ID matches, return true and delete existing contact KG
        assertFalse(contactService.deleteContact("01")); // If trying to delete the same contact twice, return false KG
    }
    
    @Test // Testing updating contact KG
    public void testUpdateContact() {
    	Contact contact = new Contact("01", "Ray", "Vans", "1112223333", "53 Cool St");
        ContactService contactService = new ContactService();
        assertEquals(true, contactService.addContact(contact));
        assertTrue(contactService.updateContact("01", "Raymond", "Vans", "1112223333", "53 Cool St"));
        assertEquals(contact.getFirstName(), "Raymond");

        
        assertEquals(true, contactService.updateContact("01", "Ray", "Vanacore", "1112223333", "53 Cool St"));
        assertEquals(contact.getLastName(), "Vanacore");
        
        assertEquals(true, contactService.updateContact("01", "Ray", "Vans", "1112224444", "53 Cool St"));
        assertEquals(contact.getPhoneNumber(), "1112224444");
        
        assertEquals(true, contactService.updateContact("01", "Ray", "Vans", "1112223333", "53 Cooler St"));
        assertEquals(contact.getAddress(), "53 Cooler St");
    }
}
        
