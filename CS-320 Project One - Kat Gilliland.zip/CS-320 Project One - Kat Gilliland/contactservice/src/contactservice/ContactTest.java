package contactservice;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;


public class ContactTest {

    @Test // Test Annotation KG
    void testContactID() {
        Contact contact = new Contact("0123456789", "Ray", "Vans", "1112223333", "53 Cool St");
        assertTrue(contact.getContact().equals("0123456789"));
        assertFalse(contact.getContact().equals(null));
    }

    @Test // Test Annotation KG
    void testContactFirstName() {
        Contact contact = new Contact("0123456789", "Ray", "Vans", "1112223333", "53 Cool St");
        assertTrue(contact.getFirstName().equals("Ray"));
        assertFalse(contact.getFirstName().equals(null));
    	}

    @Test // Test Annotation KG
    void testContactLastName() {
        Contact contact = new Contact("0123456789", "Ray", "Vans", "1112223333", "53 Cool St");
        assertTrue(contact.getLastName().equals("Vans"));
        assertFalse(contact.getLastName().equals(null));
    }

    @Test // Test Annotation KG
    void testContactPhone() {
        Contact contact = new Contact("0123456789", "Ray", "Vans", "1112223333", "53 Cool St");
        assertTrue(contact.getPhoneNumber().equals("1112223333"));
        assertFalse(contact.getPhoneNumber().equals(null));
    }

    @Test // Test Annotation KG
    void testContactAddress() {
        Contact contact = new Contact("0123456789", "Ray", "Vans", "1112223333", "53 Cool St");
        assertEquals("53 Cool St", contact.getAddress());
        assertFalse(contact.getAddress().equals(null));
    }

    @Test // Test Annotation KG
    void testContactIDNotNull() { // Testing to ensure contact ID is not null KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Ray", "Vans", "1112223333", "53 Cool St"));
    }
    
    @Test
    void testContactIDLengthLimit() { // Testing to ensure contact ID is not greater 10 KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("01234567890", "Ray", "Vans", "1112223333", "53 Cool St"));
    }

    @Test // Test Annotation KG
    void testContactFirstNameNotNull() { // Testing to ensure first name is not null KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", null, "Vans", "1112223333", "53 Cool St"));
    }
    
    @Test // Test Annotation KG
    void testContactFirstNameLengthLimit() { // Testing to ensure first name is not greater than 10 KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Bartholomew", "Vans", "1112223333", "53 Cool St"));
    }

    @Test // Test Annotation KG
    void testContactLastNameNotNull() { // Testing to ensure last name is not null KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", null, "1112223333", "53 Cool St"));
    }
    
    @Test // Test Annotation KG
    void testContactLastNameLengthLimit() { // Testing to ensure last name is not greater than 10 KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vanillandicore", "1112223333", "53 Cool St"));
    }

    @Test // Test Annotation KG
    void testContactPhoneNotNull() { // Testing to ensure phone is not null KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vans", null, "53 Cool St"));
    }
    
    @Test // Test Annotation KG
    void testContactPhoneShortLength() { // Testing to ensure phone is not less than 10  KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vans", "01010", "53 Cool St"));
    }
    
    @Test // Test Annotation KG
    void testContactPhoneLongLengthLimit() { // Testing to ensure address is not greater than 30  KG
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vans", "11122233334", "53  Cool St"));
    }

    @Test // Test Annotation KG
    void testContactAddressNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vans", "1112223333", null));
    }
    
    @Test // Test Annotation KG
    void testContactAddressLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789", "Ray", "Vans", "1112223333", "5000 Groovy Vanillandicore House Rd"));
    }
}