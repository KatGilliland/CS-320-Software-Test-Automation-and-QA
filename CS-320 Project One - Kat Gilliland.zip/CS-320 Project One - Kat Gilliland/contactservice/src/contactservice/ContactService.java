package contactservice;

import java.util.ArrayList; // Importing array list KG

public class ContactService {

	private ArrayList<Contact> contacts = new ArrayList<Contact>(0); // Setting contact array list structure to store contacts KG
    
    public boolean addContact(Contact newContact) {
    	boolean doesExist = false;
    	
    	for (Contact contact : contacts) {
    		if(contact.equals(newContact)) {
    			doesExist = true;
    		}
    	}
    	
    	if (!doesExist) {
    		contacts.add(newContact);
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    	
    public boolean deleteContact(String contactID) {
    	boolean currBool = false;
    	for(Contact contact : contacts) {
    		if (contact.getContact().equals(contactID)) {
    			currBool = contacts.remove(contact);
    			if (currBool) {
    				return currBool;
    			}
    		}
    	}
		return false;
    }
    
    public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
    	for(Contact contact : contacts) {
    		if (contact.getContact().equals(contactID)) {
    			if (firstName != null) {
    			contact.setFirstName(firstName);
    			}
    			if (lastName != null) {
    			contact.setLastName(lastName);
    			}
    			if (phoneNumber != null) {
    			contact.setPhoneNumber(phoneNumber);
    			}
    			if (address != null) {
    			contact.setAddress(address);
    			}
    			return true;
    		}
    	}
    	return false;
    }
    }
    
    	
