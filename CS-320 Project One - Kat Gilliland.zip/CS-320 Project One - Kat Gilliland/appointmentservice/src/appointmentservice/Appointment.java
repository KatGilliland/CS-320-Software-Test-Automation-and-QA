package appointmentservice;

import java.util.Date;

public class Appointment {

	private String appointmentID;
	private Date appointmentDate; // appointmentDate is a variable of type "Date" KG
	private String description;


	// Creating parameterized constructor KG
	public Appointment(String appointmentID, Date appointmentDate, String description) {

		if (appointmentID == null || appointmentID.length()>10){// Appointment ID cannot be null OR over 10 characters KG
	        throw new IllegalArgumentException("Invalid appointment ID"); // Throwing exception if appointment ID does not match expected parameters KG
	    }
		this.appointmentID = appointmentID;
		
	    if (appointmentDate == null || appointmentDate.before(new Date())){ // Appointment date cannot be null or in the past KG 
	        throw new IllegalArgumentException("Invalid appointment date"); // Throwing exception if appointment does not match expected parameters KG
	    }
	    this.appointmentDate = appointmentDate; 
	
	    if (description == null || description.length()>50){ // Description cannot be null OR over 50 characters KG 
	        throw new IllegalArgumentException("Invalid appointment description"); // Throwing exception if appointment description does not match expected parameters KG
	    }
	    this.description = description;
	}

	// Getters created below KG
	
	// Getting appointment KG
	public String getAppointment() {
	return appointmentID;
	}

	// Getting appointment date KG
	public Date getAppointmentDate() {
	return appointmentDate;
	}

	// Getting description KG
	public String getDescription() {
	return description;
	}
}