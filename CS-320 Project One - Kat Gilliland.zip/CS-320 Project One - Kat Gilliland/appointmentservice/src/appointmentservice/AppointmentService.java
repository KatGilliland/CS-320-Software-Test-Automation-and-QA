package appointmentservice;

import java.util.ArrayList;
import java.util.Iterator;

public class AppointmentService {

    private ArrayList<Appointment> appointments; // Creating appointments array list KG

    public AppointmentService() {
        appointments = new ArrayList<>();
    }

    public boolean appointmentExists(String appointmentID) { // Confirming that appointment exists based on appropriate appointment ID KG
        for (Appointment appointment : appointments) {
            if (appointment != null && appointment.getAppointment().equals(appointmentID)) {
                return true;
            }
        }
        return false;
    }

    public boolean addAppointment(Appointment newAppointment) { // Adding new appointment KG
        if (newAppointment == null) { // If new appointment is null KG
            throw new IllegalArgumentException("Appointment cannot be null"); // Throw argument KG
        }

        if (appointmentExists(newAppointment.getAppointment())) { // If appointment with entered ID already exists KG
            throw new IllegalArgumentException("This appointment ID is already assigned to an active appointment. Please try again."); // Throw argument KG
        }

        return appointments.add(newAppointment); // Return successfully created appointment KG
    }

    public void deleteAppointment(String appointmentID) { // Deleting appointment KG
        if (appointmentID == null) { // If appointment ID is null KG
            throw new IllegalArgumentException("Appointment ID cannot be null"); // Throw argument KG
        }

        Iterator<Appointment> iterator = appointments.iterator(); // Setting iterator to iterate through appointment list KG
        while (iterator.hasNext()) { // While there is another appointment KG
            Appointment appointment = iterator.next();
            if (appointment != null && appointment.getAppointment().equals(appointmentID)) { // If appointment is not null and has proper appointment ID KG 
                iterator.remove(); // Remove that next appointment KG
                return; 
            }
        }

        throw new IllegalArgumentException("Appointment with entered appointment ID cannot be found"); // Throw argument if appointment ID cannot be found KG
    }

    public ArrayList<Appointment> getAppointments() {
        return appointments; // Returning active/appropriate appointments KG
    }
}