package appointmentservice;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	
    private String appointmentID;
    private Date currDate;
    private Date appointmentDate;
    private String description;
    private String badAppointmentID;

    @BeforeEach // Creating test values for each test below KG
    void setUp() {
        currDate = new Date();
        appointmentID = "0123456789";
        appointmentDate = currDate;
        description = "Take the dog to the groomer";
        badAppointmentID = "9876543210";
    }

    @Test
    void testGetAppointment() { // Testing getting appointment KG
        AppointmentService appointmentService = new AppointmentService();
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);

        appointmentService.addAppointment(appointment); // Adding appointment with appropriate values KG
        appointmentService.getAppointment(appointmentID); // Getting the successful appointment KG
    }
    
    @Test
    void testAddAppointment() { // Testing adding appointment KG
        AppointmentService appointmentService = new AppointmentService();
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);

        assertTrue(appointmentService.addAppointment(appointment)); // Adding appointment with appropriate values KG
        assertFalse(appointmentService.addAppointment(appointment)); // Cannot add same appointment twice KG
    }

    @Test
    void testDeleteAppointment() { // Testing deleting appointment KG
        AppointmentService appointmentService = new AppointmentService();

        assertFalse(appointmentService.deleteAppointment(badAppointmentID)); // Deleting appointments with invalid appointment IDs KG

        assertTrue(appointmentService.addAppointment(appointmentID)); // Adding appointment with valid ID KG
        assertTrue(appointmentService.appointmentExists(appointmentID)); // Appointment with valid ID exists KG
        
        appointmentService.deleteAppointment(appointmentID); // Deleting appointment with valid ID KG
        assertFalse(appointmentService.appointmentExists(appointmentID)); // Confirming appointment is removed KG
        
        assertFalse(appointmentService.deleteAppointment(appointmentID)); // Cannot delete an appointment that has already been removed KG
    }
}