package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import java.util.Date;

class AppointmentTest {
	
	// Declaring variables for testing purposes KG
	private String appointmentID;
	Date currDate;
	private Date appointmentDate;
	private String description;
	private Date pastDate;
	
	@BeforeEach
	void SetUp() { // Declaring input for testing purposes KG
		currDate = new Date();
		appointmentID = "0123456789";
		appointmentDate = currDate;
		description = "Take the dog to the groomer";
		pastDate = new Date(0); 
	}
	
	@Test // Test Annotation KG
	void testAppointmentID() { // Testing creating valid appointment ID;
		Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
		assertTrue(appointment.getAppointment().equals("0123456789"));
		}

    @Test // Test Annotation KG
    void testAppointmentDate() { // Testing appointment date;
    	Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
		assertTrue(appointment.getAppointmentDate().equals(currDate));
		assertFalse(appointment.getAppointmentDate().equals(pastDate));
		}
    
    @Test // Test Annotation KG
    void testDescription() { // Testing appointment description
    	Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
    	assertTrue(appointment.getDescription().equals("Take the dog to the groomer"));
		}
		    
    @Test
    void testAppointmentIDNotNull() { // Testing to ensure appointment ID is not null KG
    	Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, appointmentDate, description));
    	}
    
    @Test
    void testAppointmentIDLengthLimit() { // Testing to ensure appointment ID is not greater 10 KG
    	Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("01234567890", appointmentDate, description));
    	}

	@Test // Test Annotation KG
	void testAppointmentDateNotNull() { // Testing to ensure appointment date is not null KG
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, null, description));
		}
	
	@Test // Test Annotation KG
	void testAppointmentDateNotBefore() { // Testing to ensure appointment date is not before new date KG
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, pastDate, description));
		}

	@Test // Test Annotation KG
	void testAppointmentDescriptionNotNull() { // Testing to ensure appointment description is not null KG
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, null));
		}
	
	@Test // Test Annotation KG
	void testAppointmentDescriptionLengthLimit() { // Testing to ensure appointment description is not greater than 50 KG
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(appointmentID, appointmentDate, "Take the dog to the groomer and don't forget to ask them to trim the dog's nails!"));
		}
	}