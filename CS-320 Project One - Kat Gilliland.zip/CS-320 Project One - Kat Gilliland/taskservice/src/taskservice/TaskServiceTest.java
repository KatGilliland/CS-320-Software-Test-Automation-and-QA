package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
// Add task test ensures tasks can be created and that IDs are unique to each task KG
	    @Test
	    void testAddTask() {
	        TaskService taskService = new TaskService();
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertTrue(taskService.addTask(task)); // Adding task first time, should return true KG
	        assertFalse(taskService.addTask(task)); // Adding the same task again, should return false KG
	    }

	    @Test
	    void testDeleteTask() {
	        TaskService taskService = new TaskService();
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertFalse(taskService.deleteTask("012")); // Cannot delete a task that does not exist, return false KG
	        
	        taskService.addTask(task); // Adding task for test KG
	        assertTrue(taskService.deleteTask("0123456789")); // If task ID matches, return true and delete existing task KG
	        assertFalse(taskService.deleteTask("0123456789")); // If trying to delete the same task twice, return false KG
	    }
	    
	    @Test
	    void testUpdateTask() {
	        TaskService taskService = new TaskService();
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertFalse(taskService.updateTask("012", "submit homework", "submit task service project for milestone")); // If trying to update a non-existent task, return false KG
	        
	        
	        taskService.addTask(task); // Adding task for test KG
	        assertTrue(taskService.updateTask("0123456789", "submit homework", "submit task service project for milestone"));
	        Task updateTask = taskService.getTask("0123456789");
	        assertTrue(updateTask.getName().equals("submit homework"));
	        assertTrue(updateTask.getDescription().equals("submit task service project for milestone"));
	    }
	}