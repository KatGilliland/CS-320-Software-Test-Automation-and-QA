package taskservice;

//Creating variables for Task class KG
public class Task {

private String taskID;
private String name;
private String description;

//Creating parameterized constructor KG
public Task(String taskID, String name, String description) {

	if (taskID == null || taskID.length()>10){// Task ID cannot be null OR greater than 10 characters KG
     throw new IllegalArgumentException("Invalid task ID"); // Throwing exception if task ID does not match expected parameters KG
 }
 if (name == null || name.length()>20){ // Name cannot be null OR over 20 characters KG 
     throw new IllegalArgumentException("Invalid name"); // Throwing exception if ID does not match expected parameters KG
 }
 if (description == null || description.length()>50){ // Description cannot be null OR over 50 characters KG 
     throw new IllegalArgumentException("Invalid description"); // Throwing exception if description does not match expected parameters KG
 }
 
 // If conditions pass, the information below is set KG
 this.taskID = taskID;
 this.name = name;
 this.description = description;
}

//Getting task KG
public String getTask() {
return taskID;
}

//Setting task KG
public void setTask(String taskID) {
this.taskID = taskID;
}

//Getting name KG
public String getName() {
return name;
}

//Setting first name KG
public void setName(String name) {
this.name = name;
}

//Getting description KG
public String getDescription() {
return description;
}

//Setting description KG
public void setDescription(String description) {
this.description = description;
}
}