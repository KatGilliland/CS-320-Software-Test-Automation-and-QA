package taskservice;

import java.util.ArrayList; // Importing array list KG

public class TaskService {

    private ArrayList<Task> tasks; // Setting task array list KG

    public TaskService() {
        tasks = new ArrayList<>();
    }
    
    public Task getTask(String taskID) { // Getting task KG
        for (Task taskList : tasks) { // Searching through task list KG
            if (taskList.getTask().equals(taskID)) { // If task exists KG
                return taskList; // Return task KG
            }
        }
        return null; // If task does not exist, return null KG
    }

    public boolean addTask(Task task) { // Using boolean to create task KG
        if (!tasks.contains(task)) { // Using contain method from array to see if task exists KG
            tasks.add(task); // Adding task if it does not exist KG
            return true; // Returning new task KG
        } else {
            return false; // Cannot add task as task already exists KG
        }
    }

   public boolean deleteTask(String taskID) { // Using boolean to delete task KG
        for (Task taskList : tasks) {
            if (taskList.getTask().equals(taskID)) { // If matching task found KG
                tasks.remove(taskList); // Remove task KG
                return true; // Deleting task if task found KG
            }
        }
        return false; // Cannot delete if contact cannot be found KG
    }

    public boolean updateTask(String taskID, String name, String description) {
        for (Task taskList : tasks) {
            if (taskList.getTask().equals(taskID)){ // Task class handles checking for null strings, setters applied directly KG
                taskList.setName(name); // Setting task name KG
                taskList.setDescription(description); // Setting task description KG
                return true; // Updating task KG
            }
        }
        return false; // Not able to update task KG 
    }
}
