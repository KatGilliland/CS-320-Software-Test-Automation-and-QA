package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

class TaskTest {

	    @Test // Test Annotation KG
	    void testTaskID() {
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertTrue(task.getTask().equals("0123456789"));
	    }

	    @Test // Test Annotation KG
	    void testName() {
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertTrue(task.getName().equals("finish homework"));
	    	}

	    @Test // Test Annotation KG
	    void testDescription() {
	        Task task = new Task("0123456789", "finish homework", "finish task service project for milestone");
	        assertTrue(task.getDescription().equals("finish task service project for milestone"));
	    }
	    
	    @Test
	    void testTaskIDNotNull() { // Testing to ensure task ID is not null KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, "finish homework", "finish task service project for milestone"));
	    }

	    @Test
	    void testTaskIDLengthLimit() { // Testing to ensure task ID is not greater 10 KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("01234567890", "finish homework", "finish task service project for milestone"));
	    }

	    @Test // Test Annotation KG
	    void testTaskNameNotNull() { // Testing to ensure task name is not null KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("0123456789", null, "finish task service project for milestone"));
	    }
	    
	    @Test // Test Annotation KG
	    void testTaskNameLengthLimit() { // Testing to ensure task name is not greater than 20 KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("0123456789", "finish homework and write down assignments for next week", "finish task service project for milestone"));
	    }

	    @Test // Test Annotation KG
	    void testTaskDescriptionNotNull() { // Testing to ensure task description is not null KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("0123456789", "finish homework", null));
	    }
	    
	    @Test // Test Annotation KG
	    void testTaskDescriptionLengthLimit() { // Testing to ensure task description is not greater than 50 KG
	        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("0123456789", "finish homework", "finish task service project for milestone but make sure to take a coffee break! Also, make suer to write down assignments for next week"));
	    }
}
